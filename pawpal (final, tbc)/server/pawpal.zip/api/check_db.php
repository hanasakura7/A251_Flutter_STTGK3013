<?php
include 'dbconnect.php';
echo "Database connection is working perfectly!";
?>